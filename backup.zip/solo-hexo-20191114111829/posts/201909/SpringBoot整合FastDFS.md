title: SpringBoot整合FastDFS
date: '2019-09-03 11:34:58'
updated: '2019-09-03 11:34:58'
tags: [SpringBoot, FastDFS, 文件存储]
permalink: /articles/2019/09/03/1567481698157.html
---
# 引入依赖
```
 <dependency>  
 <groupId>com.github.tobato</groupId>  
 <artifactId>fastdfs-client</artifactId>  
 <version>1.26.2</version>  
 <exclusions>  
 <exclusion>  
 <artifactId>logback-classic</artifactId>  
 <groupId>ch.qos.logback</groupId>  
 </exclusion>  
 </exclusions>  
 </dependency>
```
# 编写配置

```​  
fdfs.tracker-list[0]=ip地址:22122  
fdfs.nginx-host=http://nginx地址ip:8080  
```
将两个配置ip写成自己的ip

# 编写工具类

```
@Configuration  
@Import(FdfsClientConfig.class)  
// 解决jmx重复注册bean的问题  
@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)  
public class FastDFSUtil {  
​  
 private final Logger logger = LoggerFactory.getLogger(FastDFSUtil.class);  
​  
 @Value("${fdfs.nginx-host}")  
 private String nginxHost;  
​  
 @Autowired  
 private FastFileStorageClient storageClient;  
​  
 /**  
 * 上传文件  
 *  
 * @param file 文件对象  
 * @return 文件访问地址  
 * @throws IOException  
 */  
 public String uploadFile(File file) throws IOException {  
 StorePath storePath = storageClient.uploadFile(new FileInputStream(file), file.length(),  
 FilenameUtils.getExtension(file.getName()), null);  
 return getResAccessUrl(storePath);  
 }  
​  
 /**  
 * 上传文件  
 *  
 * @param file 文件对象  
 * @return 文件访问地址  
 * @throws IOException  
 */  
 public String uploadFile(MultipartFile file) throws IOException {  
 StorePath storePath = storageClient.uploadFile(file.getInputStream(), file.getSize(),  
 FilenameUtils.getExtension(file.getOriginalFilename()), null);  
 return getResAccessUrl(storePath);  
 }  
​  
 /**  
 * 将一段字符串生成一个文件上传  
 *  
 * @param content       文件内容  
 * @param fileExtension  
 * @return  
 */  
 public String uploadFile(String content, String fileExtension) {  
 byte[] buff = content.getBytes(Charset.forName("UTF-8"));  
 ByteArrayInputStream stream = new ByteArrayInputStream(buff);  
 StorePath storePath = storageClient.uploadFile(stream, buff.length, fileExtension, null);  
 return getResAccessUrl(storePath);  
 }  
​  
 // 封装图片完整URL地址  
 private String getResAccessUrl(StorePath storePath) {  
 String fileUrl = storePath.getFullPath();  
 return nginxHost + '/' + fileUrl;  
 }  
​  
 /**  
 * 传图片并同时生成一个缩略图 "JPG", "JPEG", "PNG", "GIF", "BMP", "WBMP"  
 *  
 * @param file 文件对象  
 * @return 文件访问地址  
 * @throws IOException  
 */  
 public String uploadImageAndCrtThumbImage(MultipartFile file) throws IOException {  
 StorePath storePath = storageClient.uploadImageAndCrtThumbImage(file.getInputStream(), file.getSize(),  
 FilenameUtils.getExtension(file.getOriginalFilename()), null);  
 return getResAccessUrl(storePath);  
 }  
​  
 /**  
 * 删除文件  
 *  
 * @param fileUrl 文件访问地址  
 * @return  
 */  
 public void deleteFile(String fileUrl) {  
 if (StringUtils.isEmpty(fileUrl)) {  
 return;  
 }  
 try {  
 StorePath storePath = StorePath.praseFromUrl(fileUrl);  
 storageClient.deleteFile(storePath.getGroup(), storePath.getPath());  
 } catch (FdfsUnsupportStorePathException e) {  
 logger.warn(e.getMessage());  
 }  
 }  
}

```
# 测试使用

使用controller上传
```
 @Resource  
 private FastDFSUtil fastDFSUtil;  
​  
 @PostMapping("upload")  
 public String upload(MultipartFile file) throws IOException {  
 String filePath = fastDFSUtil.uploadFile(file);  
 return filePath;  
 }
```
注意：（工具类必须放在能被SpringBoot扫描到的路径下）
